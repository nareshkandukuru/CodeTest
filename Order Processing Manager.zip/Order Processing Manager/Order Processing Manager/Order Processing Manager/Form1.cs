﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLayerProcessData;

/* Basicall this is a order processing system which covers oops basics like classes, class members like methods, event handlers, constructors
 * properties, inheritance , polymorphism, Though interfaces are not implemented, but the structure can be refactored to use interfaces
 * for better handling and reusablity and maintanence
 */

namespace Order_Processing_Manager
{   
    public partial class orderProcessSystemForm : Form
    {
        PaymentListCatalog paymentData = new PaymentListCatalog();
        BusinessRuleEngine bRuleEngine = new BusinessRuleEngine();
        paymentslipGeneratorForm pSlipGen = new paymentslipGeneratorForm();
        string physicalProductSlip = string.Empty;
        string paymentSlipText = string.Empty;
        bool activateMembership = false;
        public orderProcessSystemForm()
        {
            InitializeComponent();
        }

        private void packageSlipBtn_Click(object sender, EventArgs e)
        {
            paymentSlipText = paymentData.GenerateSlipForPhysicalProduct();
            if (radioButton1.Checked)
            {
                MessageBox.Show(paymentSlipText, "Payment Slip", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please select physical product", "Payment Slip", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
        private void memberActivationBtn_Click(object sender, EventArgs e)
        {
            activateMembership = paymentData.ActivateMembership();
            if (radioButton3.Checked)
            {
                if(activateMembership)
                {
                    MessageBox.Show("Membership activated \r\n" + "\r\n" + "\r\n" + "Mail sent", "Activate Membership", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select Membership access", "Activation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
        private void generateCommisionBtn_Click(object sender, EventArgs e)
        {
            paymentSlipText = paymentData.GenerateCommisionForAgent();
            if(radioButton1.Checked || radioButton2.Checked)
            {
                MessageBox.Show(paymentSlipText + "\r\n" + "\r\n" + "\r\n", "Agent Commision", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please select Either Physical product or Book ", "Agent Commision", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
        private void button6_Click(object sender, EventArgs e)
        {

        }
        private void memberUpgradeBtn_Click(object sender, EventArgs e)
        {
            activateMembership = paymentData.UpgradeMembership();
            if(radioButton4.Checked)
            {
                if (activateMembership)
                {
                    MessageBox.Show("Membership Upgraded successfully \r\n" + "\r\n" + "\r\n" + "Mail sent", "Upgrade Membership", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Please select Membership upgrade", "Upgrade Activation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
        private void duplicateSlipBtn_Click(object sender, EventArgs e)
        {
            paymentSlipText = paymentData.GenerateSlipForBookPurchase();
            if (radioButton2.Checked)
            {
                MessageBox.Show(paymentSlipText, "Duplicate Slip", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please select Books category", "Duplicate Slip", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
    }
}
