﻿namespace Order_Processing_Manager
{
    partial class orderProcessSystemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderManagerLbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.packageSlipBtn = new System.Windows.Forms.Button();
            this.duplicateSlipBtn = new System.Windows.Forms.Button();
            this.memberActivationBtn = new System.Windows.Forms.Button();
            this.memberUpgradeBtn = new System.Windows.Forms.Button();
            this.generateCommisionBtn = new System.Windows.Forms.Button();
            this.learnSKIBtn = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // orderManagerLbl
            // 
            this.orderManagerLbl.AutoSize = true;
            this.orderManagerLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderManagerLbl.Location = new System.Drawing.Point(250, 22);
            this.orderManagerLbl.Name = "orderManagerLbl";
            this.orderManagerLbl.Size = new System.Drawing.Size(294, 29);
            this.orderManagerLbl.TabIndex = 0;
            this.orderManagerLbl.Text = "Order Manager Console";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 221);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Activities";
            // 
            // packageSlipBtn
            // 
            this.packageSlipBtn.Location = new System.Drawing.Point(392, 136);
            this.packageSlipBtn.Name = "packageSlipBtn";
            this.packageSlipBtn.Size = new System.Drawing.Size(165, 53);
            this.packageSlipBtn.TabIndex = 2;
            this.packageSlipBtn.Text = "Generate package slip";
            this.packageSlipBtn.UseVisualStyleBackColor = true;
            this.packageSlipBtn.Click += new System.EventHandler(this.packageSlipBtn_Click);
            // 
            // duplicateSlipBtn
            // 
            this.duplicateSlipBtn.Location = new System.Drawing.Point(597, 137);
            this.duplicateSlipBtn.Name = "duplicateSlipBtn";
            this.duplicateSlipBtn.Size = new System.Drawing.Size(165, 53);
            this.duplicateSlipBtn.TabIndex = 3;
            this.duplicateSlipBtn.Text = "Generate Duplicate slip";
            this.duplicateSlipBtn.UseVisualStyleBackColor = true;
            this.duplicateSlipBtn.Click += new System.EventHandler(this.duplicateSlipBtn_Click);
            // 
            // memberActivationBtn
            // 
            this.memberActivationBtn.Location = new System.Drawing.Point(392, 215);
            this.memberActivationBtn.Name = "memberActivationBtn";
            this.memberActivationBtn.Size = new System.Drawing.Size(165, 53);
            this.memberActivationBtn.TabIndex = 4;
            this.memberActivationBtn.Text = "Membership Activate";
            this.memberActivationBtn.UseVisualStyleBackColor = true;
            this.memberActivationBtn.Click += new System.EventHandler(this.memberActivationBtn_Click);
            // 
            // memberUpgradeBtn
            // 
            this.memberUpgradeBtn.Location = new System.Drawing.Point(597, 215);
            this.memberUpgradeBtn.Name = "memberUpgradeBtn";
            this.memberUpgradeBtn.Size = new System.Drawing.Size(165, 53);
            this.memberUpgradeBtn.TabIndex = 5;
            this.memberUpgradeBtn.Text = "Upgrade Membership";
            this.memberUpgradeBtn.UseVisualStyleBackColor = true;
            this.memberUpgradeBtn.Click += new System.EventHandler(this.memberUpgradeBtn_Click);
            // 
            // generateCommisionBtn
            // 
            this.generateCommisionBtn.Location = new System.Drawing.Point(392, 293);
            this.generateCommisionBtn.Name = "generateCommisionBtn";
            this.generateCommisionBtn.Size = new System.Drawing.Size(165, 53);
            this.generateCommisionBtn.TabIndex = 6;
            this.generateCommisionBtn.Text = "Generate commision";
            this.generateCommisionBtn.UseVisualStyleBackColor = true;
            this.generateCommisionBtn.Click += new System.EventHandler(this.generateCommisionBtn_Click);
            // 
            // learnSKIBtn
            // 
            this.learnSKIBtn.Location = new System.Drawing.Point(597, 293);
            this.learnSKIBtn.Name = "learnSKIBtn";
            this.learnSKIBtn.Size = new System.Drawing.Size(165, 53);
            this.learnSKIBtn.TabIndex = 7;
            this.learnSKIBtn.Text = "Learning to SKI";
            this.learnSKIBtn.UseVisualStyleBackColor = true;
            this.learnSKIBtn.Click += new System.EventHandler(this.button6_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(7, 40);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(172, 24);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Physical Product";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(7, 70);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(72, 24);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Book";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(7, 103);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(200, 24);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Membership Access";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(6, 136);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(208, 24);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Membership Upgrade";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(7, 168);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(113, 24);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Learn SKI";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // orderProcessSystemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 434);
            this.Controls.Add(this.learnSKIBtn);
            this.Controls.Add(this.generateCommisionBtn);
            this.Controls.Add(this.memberUpgradeBtn);
            this.Controls.Add(this.memberActivationBtn);
            this.Controls.Add(this.duplicateSlipBtn);
            this.Controls.Add(this.packageSlipBtn);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.orderManagerLbl);
            this.Name = "orderProcessSystemForm";
            this.Text = "Order Processing Manager";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label orderManagerLbl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button packageSlipBtn;
        private System.Windows.Forms.Button duplicateSlipBtn;
        private System.Windows.Forms.Button memberActivationBtn;
        private System.Windows.Forms.Button memberUpgradeBtn;
        private System.Windows.Forms.Button generateCommisionBtn;
        private System.Windows.Forms.Button learnSKIBtn;
    }
}

