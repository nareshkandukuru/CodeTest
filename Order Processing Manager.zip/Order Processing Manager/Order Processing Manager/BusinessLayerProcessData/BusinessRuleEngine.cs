﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayerProcessData
{
    /* 
     * As part of the 3-tier architecture, This is a business layer which handles all the inputs from the application layer(GUI)
     * processes the data and returns the data to the application layer
     * 
     */
    public class BusinessRuleEngine
    {
        public virtual string GenerateSlipForPhysicalProduct()
        {
            return "Test packageSlipData";
        }
        public virtual string GenerateSlipForBookPurchase()
        {
            return "Test packageSlipData";
        }
        public virtual bool ActivateMembership()
        {
            return false;
        }
        public virtual bool UpgradeMembership()
        {
            return false;
        }
        public virtual string GenerateCommisionForAgent()
        {
            return "Test Commission";
        }
    }

    public class PaymentListCatalog : BusinessRuleEngine
    {
        public string physicalProductDetails;
        public override string GenerateSlipForPhysicalProduct()
        {
          physicalProductDetails = "Company Name : ABC \r\n" + "Price Details : Rs.1000INR \r\n" + "Payment validity : 5 days \r\n";
          return physicalProductDetails;
        }
        public override string GenerateSlipForBookPurchase()
        {
            physicalProductDetails = "Company Name : ABC \r\n" + "Price Details : Rs.1000INR \r\n" + "Payment validity : 5 days \r\n";
            return physicalProductDetails;
        }
        public override bool ActivateMembership()
        {
            return true;
        }
        public override bool UpgradeMembership()
        {
            return true;
        }
        public override string GenerateCommisionForAgent()
        {
            physicalProductDetails = "Company Name : MAERSK ABC \r\n" + "Commision : Rs.2000INR \r\n" + "Commision validity : 5 days \r\n";
            return physicalProductDetails;
        }
    }
}
